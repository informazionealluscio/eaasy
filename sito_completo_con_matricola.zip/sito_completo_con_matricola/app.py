from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, UserMixin, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os
import random
import string

app = Flask(__name__)
app.secret_key = 'secretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Tabelle relazionali
order_product = db.Table('order_product',
    db.Column('order_id', db.Integer, db.ForeignKey('order.id')),
    db.Column('product_id', db.Integer, db.ForeignKey('product.id'))
)

# MODELLI
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class GlobalClient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    matricola = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)

class UserClientLink(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('global_client.id'), nullable=False)

    # ✅ aggiungi questa riga
    client = db.relationship("GlobalClient", backref="user_links")


class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    description = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(50))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    client_id = db.Column(db.Integer, db.ForeignKey('global_client.id'))
    products = db.relationship('Product', secondary=order_product, backref='orders')

    # 🔧 AGGIUNGI QUESTO
    client = db.relationship("GlobalClient", backref="orders")


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ROTTE DI BASE

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'], method='pbkdf2:sha256')
        if User.query.filter_by(username=username).first():
            flash('Utente già registrato')
            return redirect(url_for('register'))
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registrazione completata')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Credenziali non valide')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/prodotti', methods=['GET', 'POST'])
@login_required
def gestione_prodotti():
    if request.method == 'POST':
        name = request.form['name']
        new_product = Product(name=name, user_id=current_user.id)
        db.session.add(new_product)
        db.session.commit()
    products = Product.query.filter_by(user_id=current_user.id).all()
    return render_template('prodotti.html', products=products)

@app.route('/clienti')
@login_required
def gestione_clienti():
    links = UserClientLink.query.filter_by(user_id=current_user.id).all()
    return render_template('clienti.html', links=links)

@app.route('/ordini/<int:client_id>')
@login_required
def lista_ordini(client_id):
    client = GlobalClient.query.get_or_404(client_id)
    orders = Order.query.filter_by(user_id=current_user.id, client_id=client.id).all()
    return render_template('ordini.html', client=client, orders=orders)

@app.route('/ordine/<int:order_id>')
@login_required
def dettaglio_ordine(order_id):
    order = Order.query.get_or_404(order_id)
    products = order.products
    return render_template('ordine_dettaglio.html', order=order, products=products)


@app.route('/product/<int:product_id>')
@login_required
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    return render_template('product_detail.html', product=product)


@app.route('/product/<int:product_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_product(product_id):
    product = Product.query.get_or_404(product_id)
    if request.method == 'POST':
        product.name = request.form['name']
        product.description = request.form['description']
        db.session.commit()
        flash('Prodotto aggiornato!')
        return redirect(url_for('product_detail', product_id=product.id))
    return render_template('product_edit.html', product=product)

# REGISTRAZIONE CLIENTI CON MATRICOLA

@app.route('/client-register', methods=['GET', 'POST'])
def client_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        if GlobalClient.query.filter_by(email=email).first():
            flash('Email già registrata')
            return redirect(url_for('client_register'))
        matricola = 'CLT-' + ''.join(random.choices(string.digits, k=6))
        password_hash = generate_password_hash(password, method='pbkdf2:sha256')
        new_client = GlobalClient(name=name, email=email, password_hash=password_hash, matricola=matricola)
        db.session.add(new_client)
        db.session.commit()
        flash(f'Registrazione completata! La tua matricola è {matricola}')
        return redirect(url_for('client_login'))
    return render_template('client_register.html')

@app.route('/client-login', methods=['GET', 'POST'])
def client_login():
    if request.method == 'POST':
        matricola = request.form['matricola']
        password = request.form['password']
        client = GlobalClient.query.filter_by(matricola=matricola).first()
        if client and check_password_hash(client.password_hash, password):
            session['client_id'] = client.id
            return redirect(url_for('client_dashboard'))
        flash('Credenziali non valide')
    return render_template('client_login.html')

@app.route('/client-dashboard')
def client_dashboard():
    client_id = session.get('client_id')
    if not client_id:
        return redirect(url_for('client_login'))

    client = GlobalClient.query.get(client_id)

    # recupera tutti gli ordini di ogni azienda che ha collegato questo cliente
    orders = Order.query.filter_by(client_id=client.id).all()
    return render_template('client_dashboard.html', client=client, orders=orders)

# COLLEGA CLIENTE A UTENTE AZIENDA
@app.route('/connect-client', methods=['GET', 'POST'])
@login_required
def connect_client():
    if request.method == 'POST':
        matricola = request.form['matricola']
        client = GlobalClient.query.filter_by(matricola=matricola).first()
        if not client:
            flash("Cliente non trovato")
            return redirect(url_for('connect_client'))
        if UserClientLink.query.filter_by(user_id=current_user.id, client_id=client.id).first():
            flash("Cliente già collegato")
        else:
            link = UserClientLink(user_id=current_user.id, client_id=client.id)
            db.session.add(link)
            db.session.commit()
            flash("Cliente collegato con successo")
        return redirect(url_for('dashboard'))
    return render_template('connect_client.html')

# CREA ORDINE PER CLIENTE COLLEGATO
@app.route('/create-order/<int:client_id>', methods=['GET', 'POST'])
@login_required
def create_order(client_id):
    client = GlobalClient.query.get_or_404(client_id)
    products = Product.query.filter_by(user_id=current_user.id).all()

    if request.method == 'POST':
        order_number = request.form['order_number']
        selected_ids = request.form.getlist('product_ids')

        order = Order(order_number=order_number, user_id=current_user.id, client_id=client.id)
        order.products = [Product.query.get(int(pid)) for pid in selected_ids]

        db.session.add(order)
        db.session.commit()
        flash("Ordine creato con prodotti!")
        return redirect(url_for('lista_ordini', client_id=client.id))

    return render_template('create_order.html', client=client, products=products)

    client = GlobalClient.query.get_or_404(client_id)
    if request.method == 'POST':
        order_number = request.form['order_number']
        order = Order(order_number=order_number, user_id=current_user.id, client_id=client.id)
        db.session.add(order)
        db.session.commit()
        flash("Ordine creato")
        return redirect(request.referrer)
    return render_template('create_order.html', client=client)

# ASSEGNA PRODOTTI ALL'ORDINE
@app.route('/assign-products/<int:order_id>', methods=['GET', 'POST'])
@login_required
def assign_products(order_id):
    order = Order.query.get_or_404(order_id)
    products = Product.query.filter_by(user_id=current_user.id).all()
    
    if request.method == 'POST':
        selected_ids = request.form.getlist('product_ids')
        order.products = [Product.query.get(int(pid)) for pid in selected_ids]
        db.session.commit()
        flash("Prodotti aggiornati!")
        return redirect(url_for('dettaglio_ordine', order_id=order.id))

    return render_template('assign_products.html', order=order, products=products)


# CLIENTE VEDE I PRODOTTI DI UN ORDINE
@app.route('/client-order/<int:order_id>')
def client_order_detail(order_id):
    client_id = session.get('client_id')
    if not client_id:
        return redirect(url_for('client_login'))
    order = Order.query.get_or_404(order_id)
    if order.client_id != client_id:
        flash("Accesso negato")
        return redirect(url_for('client_dashboard'))
    return render_template('client_order_detail.html', order=order)

# AVVIO APP
if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    with app.app_context():
        db.create_all()
    app.run(debug=True)
